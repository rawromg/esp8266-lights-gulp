# ESP8266 Websockets demo using NeoPixels

More info here: http://adityatannu.com/blog/post/2016/01/24/ESP8266-Websockets-demo-using-NeoPixels.html
